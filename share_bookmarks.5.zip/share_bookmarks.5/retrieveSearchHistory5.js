
  
  var start = 0;
  var end = 0;
  var start_end = 0;
  tabIDs=[];
  URLs=[];
  var startTime=0;
  timeSoFar=[];
  deadURL=[];
  deadURLtime=[];
  dURLcount=0;
  var SelectedTab;
  var currentWindowId;
  var historyScore=new Array();
  var tempHistory=new Array();
  var isButtonOn;
 
  var checkHist;
  var isSort;
  
  
  function clickedButton(){
  
	if ( start_end == 0)
		{
			chrome.browserAction.setIcon({path:"Images/ia_sqOn.jpg"});
			isButtonOn=true;
			start = (new Date).getTime();
			clearAllData();
			
			start_end++;
    		chrome.windows.getAll({ populate: true }, function(windowList) {
    		
				tabs = {};
				tabIds = [];
				for (var i = 0; i < windowList.length; i++) {
				    for (var j = 0; j < windowList[i].tabs.length; j++) {
				    	tabIDs[j]=windowList[i].tabs[j].id;  //get ID of tab
						URLs[ tabIDs[j]] = windowList[i].tabs[j].url;  //get associated URl
						timeSoFar[ tabIDs[j] ]=0;  //tracks how long a tab is selected
					}	
			    }
		
			});
			
			 chrome.windows.getCurrent(function(currentWindow) {
   				 currentWindowId = currentWindow.id;
			});
			chrome.tabs.getSelected(currentWindowId, function(SelTab) {
				SelectedTab=SelTab.id;
				startTime=start;
			});
			
		}
	else
		{
		  	chrome.browserAction.setIcon({path:"Images/ia_sq.jpg"});

			end = (new Date).getTime();
			start_end = 0;
			isSort=false;
			
			//stop time recording and move all URLs to the deadURL array
			 
			timeSoFar[SelectedTab]=timeSoFar[SelectedTab]+ (end-startTime);
			for (var j=0;j<tabIDs.length;j++) {
				deadURL.push(URLs[tabIDs[j]]	);
				deadURLtime.push(timeSoFar[tabIDs[j]]);
			}
			
			
			historyToBookMarks();
			isButtonOn=false;
			//clearAllData();
			return 0;
		}
	
	
  }
  
	function printBookmarks(id) {
	 chrome.bookmarks.getChildren(id, function(children) {
		children.forEach(function(bookmark) { 
		  alert(bookmark.title+" "+bookmark.id);
		  printBookmarks(bookmark.id);
		});
	 });
	 
	}
	
  
  function historyToBookMarks(){
  
			
	chrome.history.search({
		  'text': '',              // Return every history item....
		  'startTime': start,  // that was accessed in the specific interval.
		  'endTime' : end
		},
		
		function(historyItems) {
		
			var currentDate = (new Date).toUTCString();
			var newIds = new Array(historyItems.length);
		
			if(historyItems.length>0){
			
			//create new forlder in Bookmarks Bar
			chrome.bookmarks.create({'parentId': '1',
									 'title': currentDate},
			
				function(newFolder){
					for (var i=0;i<historyItems.length;++i)  {
		  			historyScore[i]=new Array(2);
		  			historyScore[i][0]=0;
		  			historyScore[i][1]=i;
					for (var j=0;j<deadURL.length;j++)	 {
						if (historyItems[i].url==deadURL[j]) 	{
							historyScore[i][0]=historyScore[i][0]+deadURLtime[j];
							
						}	
					}
		  		}
		  	
		   		checkHist=historyItems;  //for debugging purposes
		  		//sort historyScore by the first column, from low to high
		 		 qsort ( historyScore, 0, historyItems.length-1 );
	 		  // For each history item,move it to the new folder
					 
					   tempHistory=new Array();
					   for (var i = historyScore.length-1; i >=0; i--) {
		  					 var histIndex=historyScore[i][1];
		  					 tempHistory.push(historyItems[histIndex]);
		  					 
		  					chrome.bookmarks.create({'parentId': newFolder.id,
									'title':historyItems[histIndex].title,
									'url':historyItems[histIndex].url
									},
									
									function(bookmark){newIds[i]=bookmark.id;}
									);
							
					  }
		  		//historyItems=tempHistory;
		   		 /*for (var i = 0; i < historyItems.length; ++i) {
					  chrome.bookmarks.create({'parentId': newFolder.id,
												'title':historyItems[i].title,
												'url':historyItems[i].url
												},
												function(bookmark){newIds[i]=bookmark.id;}
												);
					  }*/
				 isSort=true; 
				 DrawWindow();
			  });

			}		
		}//end function(historyItems) loop					 
	);
  }
  
  
  function DrawWindow()  {
  
 		//-----OPEN NEW WINDOW BEFORE SHARING (HTML-JAVASCRIPT)-----//  
 		var currentDate = (new Date).toUTCString();
		var getServices = new Array(4);
		getServices = [0,0,0,0,0];
	
		win = window.open("","Window","menubar=no,width=500,height=500,toolbar=no");
		
				
		win.document.writeln("<b>Search : </b>"+currentDate+"<br><br><b>Share on:</b>");
			
															
		//choices made -> share on twitter, facebook, delicious, google bookmarks
		win.document.writeln("<body id=\"bodyID\">")
			
			
		win.document.writeln("<a href=\"#\" id =\"anchor\"  >All!</a><br/>");
			
		win.document.writeln("<form name=\"services\">");
		win.document.writeln("<input type=\"checkbox\" name=\"service\" value=\"Facebook\"/> <img src=\"Images/facebook_logo.png\" alt=\"share on facebook\"/> Facebook<br/>");
		win.document.writeln("<input type=\"checkbox\" name=\"service\" value=\"Twitter\"/> <img src=\"Images/twitter_logo.png\" alt=\"share on twitter\"/> Twitter<br/>");
		win.document.writeln("<input type=\"checkbox\" name=\"service\" value=\"Delicious\"/> <img src=\"Images/delicious_logo.png\" alt=\"share on delicious\"/> Delicious <br/>");
		win.document.writeln("<input type=\"checkbox\" name=\"service\" value=\"Google Bookmarks List\"/> <img src=\"Images/google_logo.png\" alt=\"share on google bookmarks\"/> Google Bookmarks List");
		
		win.document.getElementById('anchor').addEventListener('click', 
															function setServices(){getServices = [1,1,1,1,1];
															win.document.services.service[0].checked=true;
															win.document.services.service[1].checked=true;
															win.document.services.service[2].checked=true;
															win.document.services.service[3].checked=true;
															win.reload();
															});

		// Input Event Listeners.
		win.document.services.service[0].addEventListener('change',
		function changeCheck(){if(getServices[0]==1) getServices[0]=0;
									else getServices[0]=1;});
			
		win.document.services.service[1].addEventListener('change',
		function changeCheck(){if(getServices[1]==1) getServices[1]=0;
									else getServices[1]=1;});
			
		win.document.services.service[2].addEventListener('change',
		function changeCheck(){if(getServices[2]==1) getServices[2]=0;
									else getServices[2]=1;});
			
		win.document.services.service[3].addEventListener('change',
		function changeCheck(){if(getServices[3]==1) getServices[3]=0;
								else getServices[3]=1;});
								
		
		//add tag name and description for services that support this
		var	searchTag = "SquirrelBookmarks";
		var searchDescription = "";
		
		win.document.writeln("<br><br>Add a tag(SquirrelBookmarks/..)<br>");
		win.document.writeln("<textarea name=\"tagArea\"></textarea>");
		win.document.writeln("<br>Add a description<br><textarea name=\"descriptionArea\"></textarea><br>");
		
		win.document.writeln("</form>");
			
		win.document.writeln("<div id=\"divBM\"></div>");		

		win.document.writeln("<b>Bookmarked Links:</b>");
		win.document.writeln("<a href=\"#\" id =\"BManchor\"  >All!</a><br/>");
			
		win.document.writeln("<form name=\"bmarksform\">");

		//for each history item - either delete or share
		for (var i = 0; i < tempHistory.length; ++i) {
				 
			win.document.writeln("<input type=\"checkbox\" name=\"bmark\" value=\"bmarks"+i+"\"/>"+tempHistory[i].title+"<br/>");
				 
		}			
	
		win.document.writeln("</form>");
				
		win.document.getElementById('BManchor').addEventListener('click', 
															function setShareable(){
															for (var i=0;i<win.document.bmarksform.length;++i)
															{
																win.document.bmarksform[i].checked = true;
															}
															win.reload();
															});
		
		//after pushing the button close window and submit selected links to selected services
		win.document.writeln("<button id =\"button2\" type=\"button\" >Share!!!</button><br/>");
		win.document.getElementById('button2').addEventListener('click',
			function share(){
		
				win.close();
	
				searchTag += win.document.services.tagArea.value;
						
				if(win.document.services.descriptionArea.value == "")
				searchDescription = tempHistory[0].title;
				else searchDescription = win.document.services.descriptionArea.value;
						
				  for(var i=0;i<tempHistory.length;++i){
					 
					  if(win.document.bmarksform[i].checked == true){
	
						var shareurl = tempHistory[i].url.replace(" ","%20");
						var sharetitle = tempHistory[i].title.replace(" ","%20");
								
						//share on facebook
						if (getServices[0]==1)
						{
						var u = tempHistory[i].url;
						var t = tempHistory[i].title;
						chrome.tabs.create({url:"http://www.facebook.com/sharer.php?u="+encodeURIComponent(u)+"&t="+encodeURIComponent(t)});
						}
						
						//share on twitter
						if (getServices[1]==1)
						{	
						chrome.tabs.create({url:"http://twitter.com/share?url="+shareurl});
						}
						
						//share on delicious
						if (getServices[2]==1)
						{		
						chrome.tabs.create({url:"https://api.del.icio.us/v1/posts/add?url="+tempHistory[i].url+"&tag="+searchTag+"&description="+searchDescription});
						}
						
						//share on google bookmarks
						if (getServices[3]==1)
						{
						chrome.tabs.create({url:"https://www.google.com/bookmarks/api/bookmarklet?output=popup&srcUrl="+shareurl+ "&snippet=&title="+sharetitle});
						}
						
					  }
				  }
			}
			
		);		
		
		win.document.writeln("</body>");
		//set Body Style
		win.document.getElementById("bodyID").style.fontFamily=" 'Comic Sans MS', cursive";

}
  
  
  
  
  //if url changes
  chrome.tabs.onUpdated.addListener(function(tabId, props) {
  	if(isButtonOn)  {
		 time=(new Date).getTime();
		 timeSoFar[tabId]=timeSoFar[tabId] + time-startTime; //add time tab was active before url change
		 startTime=time;							//refresh start time of new active url
		  deadURL[dURLcount]=URLs[tabId];
		  deadURLtime[dURLcount]=timeSoFar[tabId];
		  dURLcount++;
		  
		  timeSoFar[tabId]=0;
		chrome.tabs.get( tabId, function(tab) {
			URLs[tabId]=tab.url;
		});
 	}   
  });

  
  //switching windows
  chrome.windows.onFocusChanged.addListener(function(windowId) {
  	if(isButtonOn)  {
		  if (SelectedTab!=-1)  {   //SelectedTab is -1 if user has switched from another application to chrome, hence there was no prior selected tab
				
				time=(new Date).getTime();
				//get time interval for previous active tab
				newtime=time-startTime;
				//add it to weight so far
				timeSoFar[SelectedTab]=timeSoFar[SelectedTab]+newtime;	
		 }
			//set selected tab to new selected tab
			if (windowId!=-1) {
				chrome.tabs.getSelected(windowId, function(SelTab) {
						SelectedTab=SelTab.id;
						time=(new Date).getTime();
						startTime=time;
				});
			}
			else {
				SelectedTab=-1;
			}
  	}
  });
  
  function clearAllData() {
  	//clearAllData;
  			tabIDs=[];
  			URLs=[];
  			startTime=0;
  			timeSoFar=[];
  			deadURL=[];
  			deadURLtime=[];
  			dURLcount=0;
  			historyScore=[];
  			tempHistory=[];
  		
			
  }

 chrome.tabs.onSelectionChanged.addListener(function(tabId, props) {
 	if (isButtonOn)  {
		//update time of old active tab
		time=(new Date).getTime();
		newtime=time-startTime;  
		timeSoFar[SelectedTab]=timeSoFar[SelectedTab]+newtime; //add time to previous times tab was active
		
		SelectedTab=tabId;
		startTime=time;
 	} 
 
  
 });

 chrome.tabs.onCreated.addListener(function(newTab) {
 	if (isButtonOn)  {
		tabIds.push(newTab.id)
		URLs[newTab.id]=newTab.url;
		timeSoFar[newTab.id]=0;
		//check if tab is active
		chrome.windows.getCurrent(function(currentWindow) {
   				 currentWindowId = currentWindow.id;
		});
		chrome.tabs.getSelected(currentWindowId, function(SelTab) {
			SelectedTab=SelTab.id;
			time=(new Date).getTime();
			if(SelectedTab==newTab.id) {startTime=time;}
		});
	}
 });





 chrome.tabs.onRemoved.addListener(function(tabId) {
    if (isButtonOn) {
		deadURL[dURLcount]=URLs[tabId];
		deadURLtime[dURLcount]=timeSoFar[tabId];
		dURLcount++;
		URLs[tabId]=undefined;
		timeSoFar[tabId]=undefined;
	}
 });
 
 
 
 //------THESE ARE QUICKSORT FUNCTIONS----------//
 
 function compare ( array, left, right ) {
		 var depth = 0;
		 while ( depth < array[left].length && depth < array[right].length ) {
			if ( array[left][depth] < array[right][depth] )
				return 1;
			else if ( array[left][depth] > array[right][depth] )
				return -1;
		depth++;	    
		}
	return 0;
 }


	function qsort ( array, lo, hi ) {
	  var low  = lo;
	  var high = hi;
	  mid = Math.floor( (low+high)/2 );
	  do {
		while ( compare(array, low,  mid) > 0 )
		  low++;
		while ( compare(array, high, mid) < 0 )
		  high--;
		if ( low <= high ) {
		  swap( array, low, high );
		  low++;
		  high--;
		}
	  } while ( low <= high );
	  if ( high > lo )
		qsort( array, lo, high );
	  if ( low < hi )
		qsort( array, low, hi );
	}

	function swap ( a, i, j ) {
	  var tmp = a[i]; 
	  a[i] = a[j];
	  a[j] = tmp;
	}

   //------END QUICKSORT FUNCTIONS----------//
  
  
  
  
  

  
  chrome.browserAction.onClicked.addListener(clickedButton);
   
  chrome.browserAction.setIcon({path:"Images/ia_sq.jpg"});
